from douyin.douyin import *

if __name__ == '__main__':
    dy = DY()
    dy.run()
